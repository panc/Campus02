function addTipp(){
    
}

function ajax(resourceName, callback) {
	xhr=new XMLHttpRequest();
    
    xhr.onreadystatechange = function(){
        // Check for a completed connection
        if (xhr.readyState==4)
        {
            // 4 = "loaded"
            // And that the connection was successful from the server's point of view
            if (xhr.status==200)
            {
                callback(xhr.responseText);
            }
            else
            {
                alert("Problem retrieving data!");
            }
        }
    };
    
	xhr.open("GET", resourceName, true);
    xhr.send("");
}
function load() {
	ajax("https://panc.github.io/Campus02/MUL/06_DOM_4-AJAX_Intro/rechnung.json", loadBill);
	//ajax("rechnung.json", loadBill);
}

function loadBill(result){

	
}

function ajax(resourceName, callback)
{
	xhr=new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        // Check for a completed connection
        if (xhr.readyState==4)
        {
            // 4 = "loaded"
            // And that the connection was successful from the
            // server's point of view
            if (xhr.status==200)
            {
                callback(xhr.responseText);
            }
            else
            {
                alert("Problem retrieving data!");
            }
        }
    };
    
	xhr.open("GET", resourceName, true);
	xhr.send("");
}